package com.exemplo.produto.entity;

public enum UnidadeMedida {
    KILO, UNIDADE, GRAMA, LITRO, DUZIA
}
