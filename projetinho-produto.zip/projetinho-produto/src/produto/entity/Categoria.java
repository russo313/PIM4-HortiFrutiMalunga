package com.exemplo.produto.entity;

public enum Categoria {
    FRUTA, LEGUME, VERDURA, PROTEINA, OUTROS
}
