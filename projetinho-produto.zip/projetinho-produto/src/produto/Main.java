package com.exemplo.produto;

import com.exemplo.produto.controller.ProdutoController;

public class Main {
    public static void main(String[] args) {
        new ProdutoController().demo();
    }
}
