# Projetinho: Produto (B C E R)

Estrutura pronta para a tarefa com **B C E R**:
- **B**: Controller
- **C**: Service
- **E**: Entity
- **R**: Repository

Compilação rápida (no terminal, dentro da pasta `src/`):
```bash
javac $(find . -name "*.java")
java com.exemplo.produto.Main
```

## Diagrama de Classe (Mermaid)

```mermaid
classDiagram
    direction TB

    class Produto {
      - int id
      - String nome
      - double valorUnitario
      - UnidadeMedida unidadeMedida
      - Categoria categoria
      - java.time.LocalDate dataCadastro
      + String editarValor(double valorNovo)
      + int getId()
      + String getNome()
      + double getValorUnitario()
      + UnidadeMedida getUnidadeMedida()
      + Categoria getCategoria()
      + java.time.LocalDate getDataCadastro()
    }

    class UnidadeMedida {
      <<enum>>
      KILO
      UNIDADE
      GRAMA
      LITRO
      DUZIA
    }

    class Categoria {
      <<enum>>
      FRUTA
      LEGUME
      VERDURA
      PROTEINA
      OUTROS
    }

    class ProdutoRepository {
      <<interface>>
      + void save(Produto p)
      + java.util.Optional~Produto~ findById(int id)
      + java.util.List~Produto~ findAll()
      + boolean deleteById(int id)
    }

    class InMemoryProdutoRepository

    class ProdutoService {
      + Produto criar(Produto p)
      + java.util.List~Produto~ listar()
      + java.util.Optional~Produto~ buscar(int id)
      + boolean remover(int id)
      + String atualizarValor(int id, double novoValor)
    }

    class ProdutoController {
      + void demo()
    }

    Produto --> UnidadeMedida
    Produto --> Categoria
    ProdutoService --> ProdutoRepository
    ProdutoController --> ProdutoService
    InMemoryProdutoRepository ..|> ProdutoRepository
```

> Gerado em 2025-09-12.
